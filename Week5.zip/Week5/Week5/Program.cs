﻿using System.Diagnostics.CodeAnalysis;

namespace Week5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //adding numbers 
            Console.WriteLine("Hello, World!");
            int myFavNum = 26;
            int theBestNum = 1;

            int sum;

            sum = myFavNum + theBestNum;

            Console.WriteLine(sum);

            //Professor Name 
            string professorName = "Nick";
            Console.WriteLine("Professor's Name: " + professorName);


            //favorite color 
            string favoriteColor = "Blue";
            Console.WriteLine("My favorite color is " + favoriteColor);




        }
    }
}
